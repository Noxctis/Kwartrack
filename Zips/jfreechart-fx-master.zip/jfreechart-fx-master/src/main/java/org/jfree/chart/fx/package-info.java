/**
 * Contains the key classes {@link org.jfree.chart.fx.ChartViewer} and 
 * {@link org.jfree.chart.fx.ChartCanvas}.
 */
package org.jfree.chart.fx;
