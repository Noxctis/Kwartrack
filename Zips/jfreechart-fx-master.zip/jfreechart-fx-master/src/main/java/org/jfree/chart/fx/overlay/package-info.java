/**
 * Contains classes that implement overlay functionality.
 */
package org.jfree.chart.fx.overlay;
